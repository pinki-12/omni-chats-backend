import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import cookieParser from "cookie-parser";



//  import routes
import authRouter from "./api/routes/auth.routes.js";
import chatRouter from "./api/routes/chat.routes.js";
import messageRouter from "./api/routes/message.routes.js";
import aiRoutes from "./routes/ai.route.js";

const app = express();

//  config:
dotenv.config();

//  middlewares:
app.use(
  cors({
    origin: ["http://localhost:5173", "http://localhost:5174", "https://text07.vercel.app"],
    credentials: true,
  }),
);
app.use(express.json());

app.use(cookieParser());

//  routes:
app.use("/api/auth", authRouter);
app.use("/api/chats", chatRouter);
app.use("/api/messages", messageRouter);
app.use("/api/ai", aiRoutes);

export default app;
